package org.aguzman.poointerfaces.repositorio;

public enum Direccion {
    ASC, DESC
}
